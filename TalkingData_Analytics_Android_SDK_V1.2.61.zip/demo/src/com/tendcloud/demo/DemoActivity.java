package com.tendcloud.demo;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.tendcloud.tenddata.TCAgent;

public class DemoActivity extends Activity {
	private Button button_test1;
	private Button button_test2;
	private Button button_map;
	private Button button_error;
	private Button button_crash;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		TCAgent.LOG_ON=true;
		TCAgent.init(this);
		TCAgent.setReportUncaughtExceptions(true);
		initViews();
		setListener();
	}

	private void initViews() {
		button_test1 = (Button) findViewById(R.id.button_test1);
		button_test2 = (Button) findViewById(R.id.button_test2);
		button_map = (Button)findViewById(R.id.button_test3);
		button_error = (Button) findViewById(R.id.button_error);
		button_crash = (Button) findViewById(R.id.button_crash);
	}

	private void setListener() {
		button_test1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				TCAgent.onEvent(DemoActivity.this, "event_ID");
				Toast.makeText(DemoActivity.this, "button_test1", -5).show();
			}
		});

		button_test2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				TCAgent.onEvent(DemoActivity.this, "event_ID", "事件标签");
				Toast.makeText(DemoActivity.this, "button_test2",
						Toast.LENGTH_SHORT).show();
			}
		});
		
		button_map.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// 应用市场中游戏的下载情况：游戏类型，下载次数，价格
				// Map的Value只能是字符串（String）和数字（Number）类型，并且一次事件最多只支持10个参数
				double number = Math.random()*(Math.random()>0.5?1:-1);
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("游戏类型", "益智游戏");
				map.put("下载次数", 100000);
				map.put("price", number);
				TCAgent.onEvent(DemoActivity.this, "event_ID", "event_LABEL", map);
				Toast.makeText(DemoActivity.this, "button_test3",
						Toast.LENGTH_SHORT).show();
			}
		});

		button_error.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				try {
					int[] array = new int[5];
					array[6] = 10;
				} catch (Exception e) {
					TCAgent.onError(DemoActivity.this, e);
					Toast.makeText(DemoActivity.this, "button_error",
							Toast.LENGTH_SHORT).show();
				}
			}
		});

		button_crash.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				int[] array = new int[5];
				array[6] = 10;
			}
		});
	}

	@Override
	protected void onResume() {
		super.onResume();
		TCAgent.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		TCAgent.onPause(this);
	}
}